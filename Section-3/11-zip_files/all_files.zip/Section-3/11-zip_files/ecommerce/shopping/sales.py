
# so if we run this , the name will show as our main
# print("Sales Initialized", __name__) # Sales Initialized __main__


def calc_tax():
    pass

def calc_shipping():
    pass



# let us write a little script for this

if __name__ == "__main__":
    print("Sales Initialized")
    calc_tax()        